package com.priyanka.realestate.pojo;

import java.util.Date;

public class payment {
	
	private long bookingID;
	private long buyerID;
	private long propertyID;
	private String paymentmode;
	private long amount;
	private Date dateofpayment;
	

}
